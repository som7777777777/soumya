
function showFunFact() {
  const fact = document.getElementById("fun-fact");
  fact.classList.toggle("hidden");
}
